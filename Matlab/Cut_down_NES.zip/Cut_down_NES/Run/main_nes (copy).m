close all
clear all

addpath( '../Source' ); addpath( '../Data' );

tic

% --- Computational Parameters ----------------------------

Model = '001'; % --- Determines Local Thermodynamic Conditions
N_g   = 40;    % --- Number of Energy Groups (Must be 40)

t_end  = 1.0d-02; % [ s ] Final time
t      = 1.0d-15; % [ s ] Initial time
t_W0   = 1.0d-10; % [ s ] Initial write time
dt_min = 1.0d-16; % [ s ] Minimum time step
dt_max = 1.0d-01; % [ s ] Maximum time step
dt     = 1.0d-15; % [ s ] Initial time step
dt_grw = 1.003;    % Max dt growth per time step
dt_dec = 0.90;    % Decline factor for dt if restep

dt_FE  = dt;
dt_EA  = dt;
dt_PE  = dt;

reStart  = 0;       % For restarting run at a specific data file

G_A = 7.5d-01;    % Gaussian Amplitude
G_B = 1.0d+02;    % Gaussian Expected Value
G_C = sqrt(50.0); % Gaussian Width

cycleM = 10^9;    % Maximum Cycles
cycleD = 100;     % Display Interval
cycleW = 10;      % Write Interval

tolPE = 1.0d-01;  % Partial Equilibrium Tolerance
tolC  = 1.0d-09;  % Particle Conservation Tolerance
tolBE = 1.0d-08;  % Convergence Tolerance For Backward Euler
tolN  = 1.0d-02;  % Relative Density Tolerance For Methods 

FE    = 0;
EA    = 1;
FE_PE = 2;
QSS1  = 4;
QSS2  = 5;
BE    = 6;

Scheme  = 'ExplicitAsymptotic';

Comment = '';

PlotFileDir    = './Output';
PlotFileName   = 'PlotFile';
PlotFileNumber = 0;
RestartDir     ='./Output';
RestartFileName ='PlotFile';
RestartFileNumber = 0;
nPlotFiles = 100; 

%--- Logs Important Parameters Into A File ---

Logfile(t_end, t, t_W0, dt, G_A, G_B, G_C, tolC, Scheme, Comment);  

% ---------------------------------------------------------

[ eC, dV, R_In, R_Out, N_Eq ] = InitializeNES( Model, N_g );

% --- Multiply Rates with Momentum Space Volume Element ---
R_In_H  = R_In  * diag( dV );
R_Out_H = R_Out * diag( dV );

if (reStart == 1) 
    
    % --- Use file to set initial density --- 
    N_0   = RestartCalculation( RestartDir, RestartFileName, RestartFileNumber);
    
else   

    % --- Gaussian Initial Condition ---
    N_0 = G_A .* exp( - 0.5 .* ( ( eC - G_B ) ./ G_C ).^2 );

end

Nold  = N_0;

[ cMat, kVec ]...
  = BuildCollisionMatrix_NES( R_In, R_Out, Nold, dV, N_g, 0.0 );

done   = false;
reStep = false;
cycle  = 0;
true_cycle = 0;
nIterations = 0;
nTrueIterations = 0;
maxFPIterations = 10000; 
mAA = 3; 
% --- Write Initial Condition ---

PlotFileNumber...
  = Write_Plotfile...
      ( t, dt, Nold, eC, dV, kVec, cMat, 0, 0, 0, 0, FE, dt, dt, dt, PlotFileDir, PlotFileName, PlotFileNumber );

wrtTimes = logspace( log10(t_W0), log10(t_end), nPlotFiles );
wrtCount = 1;

while not( done )
  
  true_cycle = true_cycle + 1;  
    
  if( not( reStep ) )
    cycle = cycle + 1;
  end
  
  % --- Perturb The Density ---
  Nold = ApplyPerturbation(Nold, amp, dV, N_g, PertCase);
 
  switch Scheme
    
    case 'ExplicitAsymptotic'
        
      Branch = EA;
        
      [ cMat, kVec ]...
        = BuildCollisionMatrix_NES( R_In, R_Out, Nold, dV, N_g, 0.0 );
      
      dt_FE = min( 1.0 ./ kVec );
       
      if( reStep )
        dt = dt_dec * dt;
        reStep = false;
      else
        dt = dt_grw * dt;
      end
    
      if( dt <= dt_FE )
          
        Nnew = Nold + dt .* ( cMat * Nold );
        
      else 
          
        Nnew = Nold + ( dt./(1.0+kVec.*dt) ) .* ( cMat * Nold );
        
        if( abs( sum(Nnew.*dV) - sum(Nold.*dV) ) / sum(Nold.*dV) > tolC )
        reStep = true;
        end
        
        if ( max( abs( Nnew - Nold ) ./ max( Nold, 1.0d-8 ) ) > tolN )
            reStep = true; 
        end
        
      end 
      
    case 'PartialEquilibrium'
        
      Branch = FE_PE; 
        
      [ cMat, kVec ]...
        = BuildCollisionMatrix_NES( R_In, R_Out, Nold, dV, N_g, tolPE );
    
      dt = min( min( 1.0 ./ kVec ), dt_grw * dt );
    
      Nnew = Nold + dt .* ( cMat * Nold ); 
      
    
      
    case 'QuasiSteadyState'
      
      Branch = QSS1;
      
      if( reStep )
        dt = dt_dec * dt;
        reStep = false;
      else
        dt = dt_grw * dt;
      end
      
      [ F0, k0 ] = ComputeRates( R_In, R_Out, Nold, dV);
    
      exp_kdt = exp( - dt .* k0 );
      
      dt_FE = min( 1.0 ./ k0 );
      
      if( dt <= dt_FE )
          
        [ cMat, kVec ]...
             = BuildCollisionMatrix_NES( R_In, R_Out, Nold, dV, N_g, 0.0 );
         
        Nnew = Nold + dt .* ( cMat * Nold );  %ForwardEulerupdate
        
        nTrueIterations = nTrueIterations + 1 ;
        
      else 
          
        [ cMat, kVec ]...
        = BuildCollisionMatrix_NES( R_In, R_Out, Nold, dV, N_g, 0.0 );
       
        Nnew = Nold + ( cMat * Nold ) .* ( 1.0 - exp_kdt ) ./ k0; %qss1 update
      
      end
      
      if( abs( sum(Nnew.*dV) - sum(Nold.*dV) ) / sum(Nold.*dV) > tolC )
        reStep = true;
      end

    case 'QSScorrection'
        
      Branch = QSS2;
      
      if( reStep )
        dt = dt_dec * dt; 
        reStep = false;
      else
        dt = dt_grw * dt; 
      
      end
     
      [ F0, k0 ] = ComputeRates( R_In, R_Out, Nold, dV );
      
      dt_FE = min( 1.0 ./ k0 );
       
     if( dt <= dt_FE ) %%%dt <= dt_FE
         
         [ cMat, kVec ]...
            = BuildCollisionMatrix_NES( R_In, R_Out, Nold, dV, N_g, 0.0 );
     
         Nnew = Nold + dt .* ( cMat * Nold ); %Forward Euler
        
         nTrueIterations = nTrueIterations + 1 ;
         
      else 
          
         r0 = 1.0 ./ (k0 .* dt);      %r0
         
         Alpha0 = ((160 .* r0.^3) + (60 .* r0.^2) + (11 .* r0) + 1) ...               %the first alpha
                ./((360 .* r0.^3) + (60 .* r0.^2) + (12 .* r0) + 1);
     
         Np = Nold + dt .* ( F0 - k0 .* Nold ) ./ (1.0 + (Alpha0 .* k0 .* dt));        %Np
         
         [ Fp, kp ] = ComputeRates( R_In, R_Out, Np, dV );
      
         kBAR = 0.5 .* ( kp + k0 );
      
         rBAR = 1.0 ./ (kBAR .* dt);
      
         AlphaBAR = ((160 .* rBAR.^3) + (60 .* rBAR.^2) + (11 .* rBAR) + 1) ...       %the second alpha
                  ./((360 .* rBAR.^3) + (60 .* rBAR.^2) + (12 .* rBAR) + 1);
            
         Ft = AlphaBAR .* Fp + ( 1.0 - AlphaBAR ) .* F0;
    
      
         Nnew = Nold + dt .* (Ft - kBAR .* Nold) ./ (1.0 + (Alpha0 .* kBAR .* dt));   % Nnew QSS2
          
         nTrueIterations = nTrueIterations + 2 ;
         
      end
      
      if( abs( sum(Nnew.*dV) - sum(Nold.*dV) ) / sum(Nold.*dV) > tolC )
        reStep = true;
      end
      

         
    case 'BackwardEuler'
        
        Branch = BE;
        
        [ cMat, kVec ]...
          = BuildCollisionMatrix_NES( R_In, R_Out, Nold, dV, N_g, 0.0 );
        
        dt_FE = min( 1.0 ./ kVec );
        
        if( reStep )
          dt = dt_dec * dt;
          reStep = false;
        else
          dt = dt_grw * dt;
        end
    
        if( dt <= dt_FE )
          
          Nnew = Nold + dt .* ( cMat * Nold );
        
          nTrueIterations = nTrueIterations + 1;

        else 
        
          [ Nnew, nIterations ] = NewtonRaphson( Nold, dt, R_In_H, R_Out_H, N_g, tolBE );
        
          nTrueIterations = nTrueIterations + nIterations;
          
          if ( max( abs( Nnew - Nold ) ./ max( Nold, 1.0d-8 ) ) > tolN )
            reStep = true; 
          end
        
        end
    
    otherwise
        
      % --- Default: Forward Euler ---

      Branch = FE;
      
      [ cMat, kVec ]...
        = BuildCollisionMatrix_NES( R_In, R_Out, Nold, dV, N_g, 0.0 );
    
      dt = min( min( 1.0 ./ kVec ), dt_grw * dt );
    
      Nnew = Nold + dt .* ( cMat * Nold );
      
  end

  if( not( reStep ) )
    Nold = Nnew;
    t    = t + dt;
  end
  
  if( t >= t_end || cycle >= cycleM )  
    done = true;
  end
  
  if( mod(cycle, cycleD) == 1 )
    disp( fprintf( '  Cycle = %d, t = %d, dt = %d ', cycle, t, dt ) );
  end

  if( t >= wrtTimes(wrtCount) )
      
    % --- Write data file ---   
    
    PlotFileNumber...
      = Write_Plotfile...
          ( t, dt, Nold, eC, dV, kVec, cMat, cycle, true_cycle, nIterations, nTrueIterations, Branch, dt_FE, dt_EA, dt_PE, PlotFileDir, PlotFileName, PlotFileNumber );
    
    wrtCount = wrtCount  + 1;
    
  end
    
end
totalTime = toc;
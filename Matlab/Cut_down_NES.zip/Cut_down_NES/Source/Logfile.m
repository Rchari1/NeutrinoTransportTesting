function[ ] = Logfile(t_end, t, t_W0, dt, G_A, G_B, G_C, tolC, Scheme, Comment)  
    
    savePath = './Run/Output_Log';
    fileID = fopen('log.txt', 'a');
    fprintf(fileID,' t_end =%5d\n', t_end );
    fprintf(fileID,' t     =%5d\n', t );
    fprintf(fileID,' t_W0  =%5d\n', t_W0 );
    fprintf(fileID,' dt    =%5d\n', dt );
    fprintf(fileID,' G_A   =%5d\n', G_A );
    fprintf(fileID,' G_B   =%5d\n', G_B );
    fprintf(fileID,' G_C   =%5d\n', G_C );
    fprintf(fileID,' tolC  =%5d\n', tolC );
    fprintf(fileID,' Scheme=%s\n', Scheme );
    fprintf(fileID,' Comment: %s\n', Comment );
    fprintf(fileID, '\n' );
    fclose(fileID);  
    
end
function [ RHS ] = RHS_FD( N, R_In, R_Out, N_g )

  RHS = ( ones( N_g, 1 ) - N ) .* ( R_In * N )...
        - N .* ( R_Out * ( ones( N_g, 1 ) - N ) );

end


function [ N_Restart ] = Restart(FileDir, FileName)


         FileNumber = 32; 
         N_Restart = zeros(40, 1); 
         Data = load( [ FileDir '/' FileName '_' num2str( FileNumber, '%08d' ) ] );
         
         for i = 1:40
         
             N_Restart(i,:) = Data.N(i,:); 
         
         end

end
function [ dt_out ] = ComputeTimeStep_Conservation_Bisection( kVec, cVec, dt_trial, tolC )

  dx_min = 1.0d-16;

  dtFun = @( x_k, x_c, a_dt )...
    a_dt^2 * abs( sum( x_k .* x_c ./ ( 1.0 + a_dt .* x_k ) ) ) - tolC;

  if( dtFun( kVec, cVec, dt_trial ) <= 0.0 )
    
    dt_out = dt_trial;
    
  else
      
    % --- Do Bisection ---
    
    x_a = 0.0;
    f_a = dtFun( kVec, cVec, x_a );
    
    x_b = dt_trial;
    f_b = dtFun( kVec, cVec, x_b );
    
    dx = x_b - x_a;

    CONVERGED = false;
    iteration = 0;
    while ( not( CONVERGED ) )
    
      iteration = iteration + 1;
      
      dx = dx / 2.0;
      
      x_c = x_a + dx;      
      f_c = dtFun( kVec, cVec, x_c );
      
      if( f_a * f_c < 0.0 )
        x_b = x_c;
        f_b = f_c;
      else
        x_a = x_c;
        f_c = f_c;
      end
      
      if( dx < dx_min )
        CONVERGED = true;
      end
          
    end
    
    dt_out = x_a;
      
  end
    
end
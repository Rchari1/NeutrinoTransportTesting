function [ JAC ] = JAC_FD( N, R_In, R_Out, N_g )

  R_In (logical( eye( size( R_In  ) ) )) = 0.0;
  R_Out(logical( eye( size( R_Out ) ) )) = 0.0;

  JAC = zeros( N_g );

  % Off-Diagonal Components:
  for k = 1 : N_g
    JAC(:,k) = ( 1.0 - N(:,1) ) .* R_In(:,k) - N(:,1) .* R_Out(:,k);
  end
  
  % Diagonal Components:
  JAC(logical( eye( size( JAC ) ) ))...
    = - ( R_In * N + R_Out * ( ones( N_g, 1 ) - N ) );

end


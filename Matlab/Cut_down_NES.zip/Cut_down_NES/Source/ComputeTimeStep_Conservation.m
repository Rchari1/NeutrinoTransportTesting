function [ dt_out ] = ComputeTimeStep_Conservation( kVec, cVec, dt_trial, tolC )

  aTol  = 1.0d-10;
  rTol  = 1.0d-12;
  dtmax_guess = 6.0d-14;
  
  
  


  dtFun = @( x_k, x_c, a_dt )...
    a_dt^2 * abs( sum( x_k .* x_c ./ ( 1.0 + a_dt .* x_k ) ) );
  
  dtJac = @( x_k, x_c, a_dt )...
    2 * a_dt * abs(sum(x_k .* x_c ./( 1.0 + a_dt .* x_k))) - a_dt^2 * (sum(x_k .* x_c ./( 1.0 + a_dt .* x_k)) ./abs(sum(x_k .* x_c ./( 1.0 + a_dt .* x_k)))) .* sum( x_k .* x_c .*x_k ./ (1.0 + a_dt .* x_k).^2);


    
  if( dtFun( kVec, cVec, dt_trial ) <= tolC )
    
    dt_out = dt_trial;
    
  else
      
    % --- Do Newton-Raphson ---

    CONVERGED = false;
    CONVERGED_MAX = false;
    iteration = 0;
    iteration_max = 0;
    
    i_max = find( abs(kVec .* cVec ./(1.0 + dt_trial .* kVec)) == max(abs(kVec .* cVec ./(1.0 + dt_trial .* kVec))));
    k_max = kVec(i_max);
    c_max = abs(cVec(i_max));
    
    f_resid_max = (40 * dtmax_guess^2 * k_max * c_max /(1 + dtmax_guess * k_max)) - tolC;
    f_deriv_max = (80 * dtmax_guess * k_max * c_max /(1 + dtmax_guess * k_max)) - (40 * dtmax_guess^2 *  k_max * c_max /(1 + dtmax_guess * k_max)^2);
    f_max_0 = f_resid_max;
    
    
    while ( not(CONVERGED_MAX) )
        
        iteration_max = iteration_max + 1;
        
        h_max = - f_resid_max/f_deriv_max; 
        
        dtmax_guess = dtmax_guess + h_max;
       

       
       f_resid_max = (40 * dtmax_guess^2 * k_max * c_max /(1.0 + dtmax_guess * k_max)) - tolC;
       f_deriv_max = (80 * dtmax_guess * k_max * c_max /(1.0 + dtmax_guess * k_max )) - (40 * dtmax_guess^2 *  k_max * c_max /(1.0 + dtmax_guess * k_max)^2);
       
        

        if( abs(f_resid_max) < aTol * abs(f_max_0) && abs(h_max/dtmax_guess) < rTol )
            CONVERGED_MAX = true;
        end
        
        if( iteration_max >= 10 )
            [ f_resid_max, f_max_0 ];
        end
    end
    
    dt_out = dtmax_guess;
    f_delta = dtFun( kVec, cVec, dt_out ) - tolC; 
    deriv_f = dtJac( kVec, cVec, dt_out );
    
    f_delta_0 = f_delta;
    
    while ( not(CONVERGED) )
        
        if (dt_out < 0 )
            
            break
        
        end

       
        iteration = iteration + 1;
      
        h = - f_delta / deriv_f;
      
        dt_out = dt_out + h;

        f_delta = dtFun( kVec, cVec, dt_out ) - tolC; 
        deriv_f = dtJac( kVec, cVec, dt_out );

      
      if( abs(f_delta) < aTol * abs(f_delta_0) && abs(h/dt_out) < rTol )
        CONVERGED = true;
      end
      
      if( iteration >= 10 )
        [ f_delta, f_delta_0 ];
      end
          
    end
      
  end
    
end
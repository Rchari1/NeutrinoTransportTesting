function [ Nnew, nIterations ] = NewtonRaphson( Nold, dt, R_In, R_Out, N_g, Tol )

  Nnew = Nold;

  converged   = false;
  nIterations = 0;
  while ( not( converged ) )

    dN = ( eye( N_g ) - dt .* JAC_FD( Nnew, R_In, R_Out, N_g ) )...
         \ ( ( Nold - Nnew ) + dt .* RHS_FD( Nnew, R_In, R_Out, N_g ) );
    
    Nnew = Nnew + dN;
    
    nIterations = nIterations + 1;
    
    if( norm( dN ./ Nnew ) < Tol )
      converged = true;
    end
          
  end

end


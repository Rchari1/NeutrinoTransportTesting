function [ G ] = GVec_FP(Nold, N, dt, R_In_H, R_Out_H, N_g)

   eta = R_In_H * N; 
   k   = R_In_H * N + R_Out_H * (ones(N_g,1) - N); 
   
   G   = ( Nold + dt .* eta ) ./ ( 1.0 + dt .* k );
   
end


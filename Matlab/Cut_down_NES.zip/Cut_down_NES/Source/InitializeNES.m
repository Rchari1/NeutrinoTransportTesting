function [ eC, dV, R_In, R_Out, N_Eq ] = InitializeNES( Model, N_g )

  % --- Energy Bin Centers ---
  
  [ eC ] = ReadData1D( 'NES_RATES_EnergyBinCenter.dat', N_g );

  % --- Energy Bin Widths ---
  
  [ de ] = ReadData1D( 'NES_RATES_EnergyBinWidth.dat', N_g );

  % --- Energy Bin Volume ---
  
  dV = ( (eC+0.5d0*de).^3 - (eC-0.5d0*de).^3 )/3.0d0;
  
  % --- NES In-Scattering Rates ---
  
  [ R_In ] = ReadData2D( ['NES_RATES_R_In___' Model '.dat'], N_g, N_g );
  
  R_Out = R_In'; % Impose In-Out Symmetry
  
  switch Model
    case '001'
      mu = 145.254;
      kT = 20.5399;
      N_Eq = 1.0 ./ ( exp( (eC-mu)./kT ) + 1.0 );
      for j = 1 : N_g
      for i = 1 : N_g
        if( j < i ) % --- Impose Detailed Balance
          R_In(i,j) = R_In(j,i) * exp( ( eC(j) - eC(i) ) / kT );
        end
      end
      end
      R_Out = R_In'; % --- Impose In-Out Symmetry
    case '002'
      mu = 045.835;
      kT = 15.9751;
      N_Eq = 1.0 ./ ( exp( (eC-mu)./kT ) + 1.0 );
      for j = 1 : N_g
      for i = 1 : N_g
        if( j < i ) % --- Impose Detailed Balance
          R_In(i,j) = R_In(j,i) * exp( ( eC(j) - eC(i) ) / kT );
        end
      end
      end
      R_Out = R_In'; % --- Impose In-Out Symmetry
     %N_Eq = 1.0 ./ ( exp( (eC-045.835)./15.9751 ) + 1.0 );
    case '003'
      mu = 020.183;
      kT = 07.7141;
      N_Eq = 1.0 ./ ( exp( (eC-mu)./kT ) + 1.0 );
      for j = 1 : N_g
      for i = 1 : N_g
        if( j < i ) % --- Impose Detailed Balance
          R_In(i,j) = R_In(j,i) * exp( ( eC(j) - eC(i) ) / kT );
        end
      end
      end
      R_Out = R_In'; % Impose In-Out Symmetry
    case '004'
      mu = 009.118;
      kT = 07.5830;
      N_Eq = 1.0 ./ ( exp( (eC-mu)./kT ) + 1.0 );
      for j = 1 : N_g
      for i = 1 : N_g
        if( j < i ) % --- Impose Detailed Balance
          R_In(i,j) = R_In(j,i) * exp( ( eC(j) - eC(i) ) / kT );
        end
      end
      end
      R_Out = R_In'; % --- Impose In-Out Symmetry
      %N_Eq = 1.0 ./ ( exp( (eC-009.118)./07.5830 ) + 1.0 );
    case '005'
      mu = 003.886;
      kT = 03.1448;
      N_Eq = 1.0 ./ ( exp( (eC-mu)./kT ) + 1.0 );
      for j = 1 : N_g
      for i = 1 : N_g
        if( j < i ) % --- Impose Detailed Balance
          R_In(i,j) = R_In(j,i) * exp( ( eC(j) - eC(i) ) / kT );
        end
      end
      end
      R_Out = R_In'; % --- Impose In-Out Symmetry
      %N_Eq = 1.0 ./ ( exp( (eC-003.886)./03.1448 ) + 1.0 );
    otherwise
      N_Eq = 1.0;
  end
  
end


function [ EOS_Table ] = ReadTable_EOS( FileName_EOS )

  % --- Read in Density, Temperature, and Electron Fraction ---
  
  EOS_Table.Rho = h5read( FileName_EOS, '/ThermoState/Density' );
  EOS_Table.T   = h5read( FileName_EOS, '/ThermoState/Temperature' );
  EOS_Table.Ye  = h5read( FileName_EOS, '/ThermoState/Electron Fraction' );
  
  % --- Read Dependent variables ---
  
  EOS_Table.Mu_e = h5read( FileName_EOS, '/DependentVariables/Electron Chemical Potential' );  

end

